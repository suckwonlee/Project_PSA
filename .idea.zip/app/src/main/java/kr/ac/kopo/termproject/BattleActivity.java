package kr.ac.kopo.termproject;

import android.app.Activity;
import android.os.Bundle;

public class BattleActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_battle);
    }
}
